/META-INF/resources/webjars/bootstrap/5.1.3/css/bootstrap.min.css
<link href="webjars/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
		<link href="webjars/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.standalone.min.css" rel="stylesheet">
