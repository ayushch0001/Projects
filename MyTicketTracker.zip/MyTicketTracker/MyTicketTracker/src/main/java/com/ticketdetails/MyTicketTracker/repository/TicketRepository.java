package com.ticketdetails.MyTicketTracker.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ticketdetails.MyTicketTracker.entity.Ticket;

@Repository
public interface TicketRepository extends JpaRepository<Ticket,Integer>
{


	@Query("SELECT t FROM Ticket t WHERE t.ticketTitle LIKE %:titleOrDescription% or t.ticketShortDescription LIKE %:titleOrDescription%")
	public  List<Ticket> searchByTitle(String titleOrDescription);
	
}

