package com.ticketdetails.MyTicketTracker.service;

import java.util.List;

import com.ticketdetails.MyTicketTracker.entity.Ticket;

public interface TicketService {

	public void addTicket(Ticket ticket);

	public Ticket showTicket(int id);
	
	public Ticket updateTicket(int id);
	
	public void deleteTicket(int id);
	
	public List<Ticket> search(String title);
	
	public List<Ticket> showList();

	
	
}
//Create, Read, Update, Delete, Search