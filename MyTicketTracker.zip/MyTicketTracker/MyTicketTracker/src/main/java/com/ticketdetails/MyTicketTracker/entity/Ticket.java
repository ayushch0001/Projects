package com.ticketdetails.MyTicketTracker.entity;





import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Data
@Table(name="tickets")
public class Ticket {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Id")
	public int id;
	
	@Column(name="ticket_title")
	public String ticketTitle;
	
	@Column(name="discription")
	public String ticketShortDescription;
	
	@Column(name="content")
	public String content;
	
	@Column(name="date")
	public LocalDate date;
  
	
}
