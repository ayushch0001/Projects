package com.ticketdetails.MyTicketTracker.controller;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.ticketdetails.MyTicketTracker.entity.Ticket;
import com.ticketdetails.MyTicketTracker.service.TicketServiceImpl;

@Controller
@RequestMapping("/ticket")
public class TicketController {

	
	@Autowired
	TicketServiceImpl  ticketServ;
	
	
	@RequestMapping("/ticketList")
	public String ticketList(Model model) {
		
		List<Ticket> tickets = ticketServ.showList();
		model.addAttribute("tickets",tickets);
		model.addAttribute("header","List Tickets");
		return "TicketList";
	}
	
	
	@RequestMapping("/addTicket")
	public String addTicket(Model model) {
		
		
		Ticket temp = new Ticket();
		model.addAttribute("temp",temp);
		model.addAttribute("header","Add Ticket");
		return "AddTicket";
		
	}
	
	@RequestMapping("/update")
	public String updateTicket(@RequestParam("id")int id,Model model) {
	
		Ticket temp = ticketServ.showTicket(id);
		model.addAttribute("temp",temp);
		model.addAttribute("header","Edit Ticket");
		return "AddTicket";
		
	}
	
	@RequestMapping("/save")
	public String saveTicket(@ModelAttribute("temp")Ticket ticket) {
		ticket.setDate(LocalDate.now());
		ticketServ.addTicket(ticket);
		return "redirect:/ticket/ticketList";
		
	}
	
	
	@RequestMapping("/delete")
	public String deleteTicket(@RequestParam("id")int id) {
	
		ticketServ.deleteTicket(id);
		return "redirect:/ticket/ticketList";
		
	}

	@RequestMapping("/search")
	public String search(@RequestParam("search")String title,Model model) {

		List<Ticket> tickets = ticketServ.search(title);
		model.addAttribute("tickets",tickets);
		model.addAttribute("header","Sorted Tickets");
		return "TicketList";
		
	}
	
	@RequestMapping("/view")
	public String search(@RequestParam("id")int id ,Model model) {

		Ticket temp = ticketServ.showTicket(id);
		model.addAttribute("temp",temp);
		return "view";
		
	}
}
