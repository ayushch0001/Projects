package com.ticketdetails.MyTicketTracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ticketdetails.MyTicketTracker.entity.Ticket;
import com.ticketdetails.MyTicketTracker.repository.TicketRepository;

@Service
public class TicketServiceImpl implements TicketService{

	
	@Autowired
	TicketRepository ticketRepo;
	
	@Override
	public void addTicket(Ticket ticket) {
	
		ticketRepo.save(ticket);
		
	}
	@Override
	public Ticket showTicket(int id) {
		
		Ticket temp = ticketRepo.findById(id).get();
		return temp;
	}

	@Override
	public Ticket updateTicket(int id) {
	
		Ticket temp = ticketRepo.findById(id).get();
		return temp;
		
	}

	@Override
	public void deleteTicket(int id) {
		
		ticketRepo.deleteById(id);
		
	}

	@Override
	public List<Ticket>  search(String title) {

		List<Ticket> temp=ticketRepo.searchByTitle(title);
		return temp;
		
	}
	@Override
	public List<Ticket> showList() {
		
		return ticketRepo.findAll();
		
		
	}

}
